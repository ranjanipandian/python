'''
several methods are used in list
'''
#append method
list1=['ranjani']
list2=['pandian']
list1.append(list2)
print(list1)

#count method
list1=['naveen','diya','priya','naveen']
print(list1.count('naveen'))

#extend() method
list1=['hi','everyone','welcome','to','my','github']
list2=[*range(5)]
print(list2)
list1.extend(list2)
print(list1)

#index() method
list1=['ranjani','anitha','amutha']
list2=['pandian']
list1.append(list2)
print(list1)
print(list1.index(list2))
