"""
id is an inbuilt operator in python which returns the 
uniform id number provided by python interpreter to a particular object
"""

a=20
b=20
if(a is b):
        print("yes")
else:
        print("no")
        
a=20
b=a
if(a is b):
        print("yes")
else:
        print("no")