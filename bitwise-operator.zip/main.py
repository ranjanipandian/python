a=60
b=87
c=a&b
print(bin(c))