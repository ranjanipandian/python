'''
when special characters are included in a string means then 
there will be a back slash included in them but if the string 
already consider that back slash meas also it will not be printed.
so print the string as a raw string where a symbol r is included 
before a string so that the complete string is printed with all the b;ack slashes in them
it is used only when 2 back slashes are followed by one another
'''
'''
raw string
''' 
print('C:\\demo')
print(r'C:\\demo')