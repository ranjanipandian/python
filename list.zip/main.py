"""
list contain objects of different datatypes not a similar ones
"""
list=[1.0,-2,3+5j,"naveen"]
print(list)

"""
list built-in functions
"""
#len() functions
list1=['physics','biology','english']
print(len(list1))

#range function
l=[*range(5)]
print(l)

#max() function
list3,list4=[['tira','raja'],['7','12']]
print(max(list3))
print(max(list4))

#min() function
print(min(list3))
print(min(list4))
 
#tuple and string to tuple function
t=(1,3,44,19,'divya','kaveri')
l=list(t)
print(l)

str="hello world"
l2=list(str)
print(l2)




