'''
while loop single statement
'''

flag=5
while(flag<=5):print('Given flag is really true!')
print("Good Bye!")
