'''
from key method in the 
below example every tuple is considered as 
a key therefore it it printed as dict with a 
values of none.
'''
seq=('name','age','sex')
dict1=dict.fromkeys(seq)
print(dict1)


seq=('name','age','sex')
dict1=dict.fromkeys(seq,19)
print(dict1)

'''
get method it returns the value 
associated with the key
'''
items={'name':'ranjani','age':23,'sex':'female'}
print(items.get('name'))
