'''
string formats
'''
name='qwertyuiop'
print(name)
age=4
print("age=%d" %age)
print("age is %s" %age)
print("age=%f" %age)
print("age in octal %o " %age)
print("age in hexadecimal %x " %age)
print("age with exp %e " %age)


'''
encode and decoding functions
'''
import base64
str="Hello World is the basic program!!!"
#encode will print the binary representation  of the given string
str=base64.b64encode(str.encode('utf-8'))
print("THE ENCODED STRING: ",str)
#decode will print the original value of the string
str=base64.b64decode(str).decode('utf-8')
print("THE DECODED STRING: ",str)