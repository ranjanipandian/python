#type error
str='arun'
age=20
print(str+age)


#concatenation of string
str='arun'
age='20'
print(str+ " " +age)


a="arun"
b=20
print(a+str(b));


#complex numbers
a=1+5j
print(a.real)
print(a.imag)


#none keyword means not same as false or 0
s=None
print(s)


#typecasting
a=1+3j
print(type(a))


#arithmetic operators using next line end="\n"
a=int(input())
b=int(input())
print(a+b,end="\n")
print(a-b,end="\n")
print(a*b,end="\n")
print(a/b,end="\n")
print(a//b,end="\n")
print(a%b,end="\n")
print(a**b,end="\n")


#keyword bool
print(bool(0))
print(bool(1))
print(bool(-1))
print(bool(10))
print(bool('name'))
print(bool(1+2j))
print(bool(0+0j))


#complex cannot be typecasted
a=1+2j
print(int(a))


#example for float typecasting
a=float(input())
pi=3.14
print(pi*a*a,end="\n")
print(2*pi*a)


#realtional operators output comes as boolean form True or False
n1=10
n2=40
n3=50
print(n1<n2<n3)
print(n1==n2==n3)


#lexicographical order is done when comparing two strings in rational operation
n1='ant'
n2='ball'
print(n1<n2)
#ans is true because of the each character of 1st string is checked in alphabetic order with 2nd string
a='ball'
b='ant'
print(a<b)


'''base is the value type of the number which is coverted from the integer 
normally for integer is decimal which has a base of 10'''

#binary value = b (base 2)
a=10
print(bin(a))
#octal value = o (base 8)
print(oct(a))
#hexadeciaml value = x (base 16)
print(hex(a))

