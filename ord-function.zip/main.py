"""
int python a unit length of string is accepted as an argument 
and returns the unicode equivalece of the passed argument.
in simple word it is considered as a strig of length 1.
"""

name='a'
d=ord(name)
print(type(d))